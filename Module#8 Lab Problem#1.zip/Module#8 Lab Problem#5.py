
b = int(input("give me a function")
d = int(input("give me a function")

if items is needed:
    print("if items are needed")
else:
    if buffs & and debuffs are needed:
        print("both buffs are debuffs are needed")
    else:
        print("buffs and debuffs are not needed") 
