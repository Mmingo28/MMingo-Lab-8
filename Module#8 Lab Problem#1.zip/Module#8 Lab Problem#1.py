#import statements
import math


#define your functions

y = int(input("give me a function"))
n = int(input("give me a function"))

if y < n:
    print("y is less than n")
else:
    if n > y:
     print("n is greater than y")
    else:
        print("y and n must be equal")
    

    
    
        
