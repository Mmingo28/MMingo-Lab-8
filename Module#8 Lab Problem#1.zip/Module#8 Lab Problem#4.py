

c = int(input("give me a function")
d = int(input("give me a function")



if c takes a year:
    print(True)
else:
     if d takes a year:
         print(False)
