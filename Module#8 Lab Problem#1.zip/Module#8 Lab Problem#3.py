

mylist = int(input("give me a function"))

if 5 < 10:
    print("5 is less than 10")
else:
    if 10 > 5:
        print("10 is greater than 5")
    else:
         print("5 and 10 are not equal")
     
