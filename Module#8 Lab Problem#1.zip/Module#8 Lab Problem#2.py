
b = int(input("give me a function"))
a = int(input("give me a function"))

if b & a < 10:
    print("b & a is less than 10")
else:
     if a & b > 10:
        print("a & b is greater than 10")
     else:
         print("a and b must equal to 10")

